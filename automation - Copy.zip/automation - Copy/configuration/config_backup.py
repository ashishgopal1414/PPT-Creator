# -*- coding: utf-8 -*-

import os, sys
import pandas as pd
from pptx import Presentation
from pptx.util import Inches

#%%

FILEPATH = os.path.abspath(__file__ + "/../../")

#%%

## Slide 1

def initialize_first_slide(title, subtitle):
    # Creating presentation object
    root = Presentation()
  
    # Creating slide layout
    slide_layout_1 = root.slide_layouts[0]  ## title and subtitle
      
    """ Ref for slide types: 
    0 ->  title and subtitle
    1 ->  title and content
    2 ->  section header
    3 ->  two content
    4 ->  Comparison
    5 ->  Title only 
    6 ->  Blank
    7 ->  Content with caption
    8 ->  Pic with caption
    """
      
    # Creating slide object to add in ppt i.e. Attaching slides 
    # with Presentation i.e. ppt
    slide = root.slides.add_slide(slide_layout_1)
      
    # Adding title and subtitle in slide i.e. first page of slide 
    slide.shapes.title.text = title
      
    # We have different formats of subtitles in ppts, for simple
    # subtitle this method should implemented, you can change
    # 0 to 1 for different design
    slide.placeholders[1].text = subtitle
    
    return root

#%%
  
## Slide 2

def add_single_image_slide(root, img_path, placeholder1="", placeholder2=""):
    ## Adding Slide with Heading and 1 Image
    
#    img_path = r'C:\ASH\Fractal projects\HR Analytics\automation\data\Topic 1\1.png'
    
    # Creating slide layout
    slide_layout_2 = root.slide_layouts[1] ## title and content
    ## Attaching slide to ppt
    slide = root.slides.add_slide(slide_layout_2)
    #slide = ppt.slides.add_slide(blank_slide_layout) 
    
    ## Adding Heading
    if ((placeholder1 != "") & ~(pd.isna(placeholder1))):
        slide.placeholders[0].text = placeholder1
#    else:
#        slide.placeholders[0].text = ""
    ## Adding Placeholder Heading
    if ((placeholder2 != "") & ~(pd.isna(placeholder2))):
        slide.placeholders[1].text = placeholder2
#    else:
#        slide.placeholders[1].text = ""
    
    # Adding images
    # For margins
    left   = Inches(1.5) 
    top    = Inches(3) 
    width  = None
    height = Inches(3) 
    
    pic = slide.shapes.add_picture(img_path, 
                                   left   = left, top = top, 
                                   height = height, width=width)
    return root
      

#%%

## Slide 3

def add_double_image_slide(root, img_path1, img_path2, placeholder1="", 
                                                       placeholder2="", placeholder3="", 
                                                       placeholder4="", placeholder5=""):
    ## Adding Slide with Heading and 2 Images
    
#    img_path1 = r'C:\ASH\Fractal projects\HR Analytics\automation\data\Topic 2\1.png'
#    img_path2 = r'C:\ASH\Fractal projects\HR Analytics\automation\data\Topic 2\2.png'
    
    # Creating slide layout
    slide_layout_3 = root.slide_layouts[4] ## Comparison
    ## Attaching slide to ppt
    slide = root.slides.add_slide(slide_layout_3)
    #slide = ppt.slides.add_slide(blank_slide_layout) 
       
    ## Adding Heading
    if ((placeholder1 != "") & ~(pd.isna(placeholder1))):
        slide.placeholders[0].text = placeholder1
    ## Adding Placeholder Heading
    if ((placeholder2 != "") & ~(pd.isna(placeholder2))):
        slide.placeholders[1].text = placeholder2
#        slide.placeholders[1].text_frame = placeholder2
#        from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE
#        slide.placeholders[1].auto_size = MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT
        
    ## Adding Placeholder Sub Heading
    if ((placeholder3 != "") & ~(pd.isna(placeholder3))):
        slide.placeholders[2].text = placeholder3
    
    # Adding images
    # For margins
    left   = Inches(0.34) 
    top    = Inches(3) 
    width  = None
    height = Inches(3) 
    pic = slide.shapes.add_picture(img_path1, 
                                   left   = left, top = top, 
                                   height = height, width=width)
    
    ## Adding Placeholder Heading
    if ((placeholder4 != "") & ~(pd.isna(placeholder4))):
        slide.placeholders[3].text = placeholder4
#        slide.placeholders[3].text_frame = placeholder4
#        from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE
#        slide.placeholders[3].auto_size = MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT        

    ## Adding Placeholder Sub Heading
    if ((placeholder5 != "") & ~(pd.isna(placeholder5))):
        slide.placeholders[4].text = placeholder5
    # For margins
    left   = Inches(5) 
    top    = Inches(3) 
    width  = None
    height = Inches(3) 
    
    pic = slide.shapes.add_picture(img_path2, 
                                   left   = left, top = top, 
                                   height = height, width=width)
    
    return root


#%%