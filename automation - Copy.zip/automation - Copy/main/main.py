import os, sys, time, datetime, warnings, shutil
import pandas as pd
import numpy as np

# pip install python-pptx
from pptx import Presentation
from pptx.util import Inches
warnings.filterwarnings("ignore")

from configuration.config import FILEPATH, initialize_first_slide, add_single_image_slide, \
    add_double_image_slide, add_end_image_slide

######################################################################
level_up_folders = 3
level_up_string = "/.." * level_up_folders + "/"
sys.path.insert(1, os.path.abspath(__file__ + level_up_string))
######################################################################
## List of hardcoded folders
folder_name_data    = "data"            ## To fetch data from
folder_name_results = "results"         ## To Store results
first_slide_folder  = "00-FirstSlide"   ## This folder contains Title and Subtitle for the ppt
end_slide_folder    = "99-EndSlide"     ## This folder contains Image for the ppt

######################################################################
ppt_out_dir = os.path.join(FILEPATH, folder_name_results)

if not os.path.exists(ppt_out_dir):
    os.makedirs(ppt_out_dir)
######################################################################
inp_data_dir = os.path.join(FILEPATH, folder_name_data)

rootdir1        = inp_data_dir
subdirectories1 = [d for d in os.listdir(rootdir1) if os.path.isdir(os.path.join(rootdir1, d))]
filesavailable1 = [d for d in os.listdir(rootdir1) if os.path.isfile(os.path.join(rootdir1, d))]

######################################################################

## Level 1
print('Root Directory: {}'.format(rootdir1))

root = Presentation()

for subdir1 in subdirectories1:
    print('------------------------------------------------')
    print('Sub Directory 1: {}'.format(subdir1))

    ## Level 2
    rootdir2        = os.path.join(rootdir1, subdir1)
    subdirectories2 = [d for d in os.listdir(rootdir2) if os.path.isdir(os.path.join(rootdir2, d))]
    filesavailable2 = [d for d in os.listdir(rootdir2) if os.path.isfile(os.path.join(rootdir2, d))]

    if (subdir1 == first_slide_folder):
        title_ppt       = 'Title of the PPT - Quaterly Sales'
        subtitle_ppt    = 'Subtitle of the PPT'

        ##################################################################
        ## Initializing the ppt with first slide
        root = initialize_first_slide(title=title_ppt,
                                      subtitle=subtitle_ppt)

        ##################################################################
    elif (subdir1.startswith('01-Sales-')):
        placeholder1 = 'Monthly Sales Report'
        placeholder2 = subdir1.split('-')[-1]

        rootdir2        = os.path.join(rootdir1, subdir1)
        filesavailable2 = [d for d in os.listdir(rootdir2) if os.path.isfile(os.path.join(rootdir2, d))]

        print('        ================================================')
        print('        Files 3: {}'.format(filesavailable2))
        print('        ================================================')

        for file_name in filesavailable2:
            img_path = os.path.join(os.path.join(rootdir2, file_name))
            root = add_single_image_slide(root, img_path,
                                          placeholder1=placeholder1,
                                          placeholder2=placeholder2)

    elif (subdir1 == end_slide_folder):
        rootdir2        = os.path.join(rootdir1, subdir1)
        filesavailable2 = [d for d in os.listdir(rootdir2) if os.path.isfile(os.path.join(rootdir2, d))]

        print('        ================================================')
        print('        Files 2: {}'.format(filesavailable2))
        print('        ================================================')

        for file_name in filesavailable2:
            img_path = os.path.join(os.path.join(rootdir2, file_name))
            root = add_end_image_slide(root, img_path)

    else:
        print(f'Folder excluded! {subdir1}')
# %%
# Saving file
root.save(os.path.join(ppt_out_dir, "Output.pptx"))

print("Ppt Created Successfully!")

#######################################################
