import os, sys, time, datetime, warnings, shutil
import pandas as pd
import numpy as np
from pptx import Presentation
from pptx.util import Inches

warnings.filterwarnings("ignore")

#%%

level_up_folders    = 3
level_up_string     = "/.." * level_up_folders + "/"
sys.path.insert(1, os.path.abspath(__file__ + level_up_string))

#%%

from configuration.config import FILEPATH, initialize_first_slide, add_single_image_slide, \
                                    add_double_image_slide

#%%
## List of hardcoded folders
folder_name_data    = "data"       ## To fetch data from
folder_name_results = "results"    ## To Store results
first_slide_folder  = "FirstSlide" ## This folder contains Title and Subtitle for the ppt

#%%

ppt_out_dir = os.path.join(FILEPATH, folder_name_results)

if not os.path.exists(ppt_out_dir):
    os.makedirs(ppt_out_dir)
    
#%%

inp_data_dir = os.path.join(FILEPATH, folder_name_data)

rootdir1        = inp_data_dir
subdirectories1 = [d for d in os.listdir(rootdir1) if os.path.isdir(os.path.join(rootdir1,d))]
filesavailable1 = [d for d in os.listdir(rootdir1) if os.path.isfile(os.path.join(rootdir1,d))]

#%%

## Level 1
print('Root Directory: {}'.format(rootdir1))

## If Using Overall Template
overall_filename = 'overall_template.xlsx'
df_overall       = pd.read_excel(os.path.join(rootdir1, overall_filename))

root = Presentation()

#%%

for subdir1 in subdirectories1:
    ## subdir1 = subdirectories1[0]
    ## subdir1 = subdirectories1[1]
    ## subdir1 = subdirectories1[2]
    ## subdir1 = subdirectories1[3]
    ## subdir1 = subdirectories1[4]
    
    print('------------------------------------------------')
    print('Sub Directory 1: {}'.format(subdir1))
    
    ## Level 2
    rootdir2        = os.path.join(rootdir1, subdir1)
    subdirectories2 = [d for d in os.listdir(rootdir2) if os.path.isdir(os.path.join(rootdir2,d))]
    filesavailable2 = [d for d in os.listdir(rootdir2) if os.path.isfile(os.path.join(rootdir2,d))]

    ## If Using Overall Template
    df_part = df_overall[(df_overall['folder_structure'] == subdir1)].copy()
    df_part.reset_index(drop=True, inplace=True)
#
    ## If using indiviual parts template
    part_filename = subdir1 + ".xlsx"
#    df_part = pd.read_excel(os.path.join(rootdir2, part_filename))
    
    if (subdir1 == first_slide_folder):               
        ## when folder_structure =="FirstSlide", take the columns "title"
        title_ppt    = df_part[(df_part['folder_structure'] =="FirstSlide")]["title"][0] 
        
        ## when folder_structure =="FirstSlide", take the columns "subtitle"
        subtitle_ppt = df_part[(df_part['folder_structure'] =="FirstSlide")]["subtitle"][0] 
               
        ##################################################################
        ## Initializing the ppt with first slide
        root = initialize_first_slide(title    = title_ppt, 
                                      subtitle = subtitle_ppt)
        
        ##################################################################
    elif (subdir1.startswith('part')):
        for subdir2 in subdirectories2:
            ## subdir2 = subdirectories2[0]
            ## subdir2 = subdirectories2[1]
            ## subdir2 = subdirectories2[2]
            ## subdir2 = subdirectories2[3]
            
            print('    ................................................')
            print('    Sub Directory 2: {}'.format(subdir2))
    #        print('    Files 2: {}'.format(filesavailable2))   
            print('    ................................................')
            
            ## Level 3
            rootdir3        = os.path.join(rootdir1, subdir1, subdir2)
    #        subdirectories3 = [d for d in os.listdir(rootdir3) if os.path.isdir(os.path.join(rootdir3,d))]
            filesavailable3 = [d for d in os.listdir(rootdir3) if os.path.isfile(os.path.join(rootdir3,d))]
        
            print('        ================================================')
            print('        Files 3: {}'.format(filesavailable3))   
            print('        ================================================')
        
        
            if not df_part.empty:
                df_line = df_part[(df_part['folder_structure'] == subdir1) 
                                    & (df_part['folder_name'] == subdir2)].copy()
                df_line.reset_index(drop=True, inplace=True)
                    
                if not df_line.empty:  
                    placeholder1 = df_line['placeholder1'][0] 
                    placeholder2 = df_line['placeholder2'][0] 
                    placeholder3 = df_line['placeholder3'][0] 
                    placeholder4 = df_line['placeholder4'][0]
                    placeholder5 = df_line['placeholder5'][0]
                    
                    if df_line['folder_name'][0] == 'overall': ## 1 heading + 1 image
                        for file_name in filesavailable3:                        
                            img_path = os.path.join(os.path.join(rootdir3, file_name))              
                            root = add_single_image_slide(root, img_path, 
                                                          placeholder1 = placeholder1,
                                                          placeholder2 = placeholder2)
                            
                    elif (df_line['folder_name'][0].startswith('topic')): ## 1 heading + 2 images
                                              
                        img_path1 = os.path.join(os.path.join(rootdir3, filesavailable3[0]))              
                        img_path2 = os.path.join(os.path.join(rootdir3, filesavailable3[1]))              
                          
                        root = add_double_image_slide(root, 
                                                      img_path1    = img_path1, 
                                                      img_path2    = img_path2, 
                                                      placeholder1 = placeholder1, 
                                                      placeholder2 = placeholder2, 
                                                      placeholder3 = placeholder3, 
                                                      placeholder4 = placeholder4, 
                                                      placeholder5 = placeholder5)

        print('------------------------------------------------')



#%%
# Saving file
root.save(os.path.join(ppt_out_dir, "Output.pptx"))
  
print("Ppt Created Successfully!")


#%%# -*- coding: utf-8 -*-

# -*- coding: utf-8 -*-

